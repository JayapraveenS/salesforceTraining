import { LightningElement } from 'lwc';

export default class ModalData extends LightningElement {
    
}