import {
    LightningElement,
    api,
    track
} from 'lwc';

export default class TableRowComponent extends LightningElement {
    @api singleRecord; //{Name:__,...}        
    @api metaData; //[objApiName, [fields selected array]]      
    @track fieldApis;
    @track objectName;
    editting = false;
    connectedCallback() {
        this.fieldApis = this.metaData[1];
        this.objectName = this.metaData[0];
    }
    handleEdit() {
        this.editting = true;
    }
    reloadRequired() {
        this.dispatchEvent(new CustomEvent('reloadrequired'));
    }
}