import {
    LightningElement,
    api,
    track
} from 'lwc';
export default class TableColumnComponent extends LightningElement {
    @api singleRecord; //{Name:__,...}
    @api fieldApiName; //field__c or Name...
    @track output;
    connectedCallback() {
        this.output = this.singleRecord[this.fieldApiName];
    }
}