import {
    LightningElement,
    api,
    track
} from 'lwc';
import getDynamicVals from '@salesforce/apex/OrgData.getDynamicVals';

export default class ReusableTable extends LightningElement {
    @api content;
    @track result = [];
    @track fieldsSelected;
    @track orgAndFieldsMetadata = [];
    Offset = 0;
    Limit = 10;
    isReloading = false;
    connectedCallback() {
        console.log(JSON.parse(JSON.stringify(this.content)));
        this.getData();
    }
    getData() {
        let query = 'SELECT ' + JSON.parse(JSON.stringify(this.content[0])).fields.join(',') + ' FROM ' + JSON.parse(JSON.stringify(this.content[0])).objApiName + ' LIMIT ';
        if (this.isReloading == true) {
            let Limit2 = this.Offset + 10;
            this.result = [];
            query += Limit2 + ' OFFSET 0';
        } else {
            query += this.Limit + ' OFFSET ' + this.Offset;
        }
        this.orgAndFieldsMetadata[0] = (JSON.parse(JSON.stringify(this.content[0]))).objApiName;
        this.orgAndFieldsMetadata[1] = (JSON.parse(JSON.stringify(this.content[0])).fields); //[objApiName,[fields]]
        console.log(query);
        getDynamicVals({
            query: query
        }).then(
            (data) => {
                data.forEach(element => {
                    this.result.push(element); // so the result looks like [ {},{},{}....]
                });
                this.isReloading = false; //rollbacking isReloading to false state;
            }
        ).catch(
            (error) => {
                console.log('Error is: ' + JSON.stringify(error));
                this.isReloading = false; //rollbacking isReloading to false state;
            }
        );
    }
    LoadMore() {
        this.Offset += 10;
        this.getData();
    }
    reload() {
        this.isReloading = true;
        this.getData();
    }
}