import {
    LightningElement,
    api,
    track
} from 'lwc';

export default class InlineEditting extends LightningElement {
    @api fieldApiName; //field__c or Name...
    @api singleRecord;
    @api fieldType;

    //for handlinling changes 
    currentValue;
    isValueChanged = false;
    changedValue;

    //for finding field type
    isDate = false;
    isText = false;
    isPhone = false;
    isEmail = false;
    isNumber = false;
    isBoolean = false;
    isDatetime = false;
    isOthers = false;
    connectedCallback() {
        this.currentValue = this.singleRecord[this.fieldApiName];
        // console.log(this.fieldApiName);
        switch (JSON.parse(JSON.stringify(this.fieldType))[this.fieldApiName]) {
            case 'EMAIL':
                this.isEmail = true;
                break;
            case 'PHONE':
                this.isPhone = true;
                break;
            case 'STRING':
                this.isText = true;
                break;
            case 'CURRENCY':
                this.isNumber = true;
                break;
            case 'DATATIME':
                this.isDatetime = true;
                break;
            case 'DATE':
                this.isDate = true;
                break;
            case 'BOOLEAN':
                this.isBoolean = true;
                break;
            default:
                this.isOthers = true;
        }
    }
    valChanged() {
        this.isValueChanged = true;
    }

    fieldBlured(event) {
        if (this.isValueChanged == true && this.currentValue != event.target.value) {
            this.changedValue = event.target.value;
            this.dispatchEvent(
                new CustomEvent('valchanged', {
                    detail: {
                        field: this.fieldApiName,
                        newVal: this.changedValue
                    }
                })
            );

        }
    }

}